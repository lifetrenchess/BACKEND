package cts.travelpackagebookingsystem.enums;

public enum BookingStatus {
	CONFIRMED, CANCELLED, PENDING

}
