 package cts.travelpackagebookingsystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
//import org.springframework.cloud.netflix.eureka.EnableEurekaClient;


//@EurekaDiscoveryClient
@SpringBootApplication
public class TravelpackagebookingsystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(TravelpackagebookingsystemApplication.class, args);
	}

}
